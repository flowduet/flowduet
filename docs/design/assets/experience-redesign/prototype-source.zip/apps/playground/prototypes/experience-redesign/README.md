# FlowDuet 体验讨论原型

2026-10-14 的可丢弃布局与视觉比较稿，仅使用模拟内容与操作，不接入真实设计器、存储或部署。

## 运行

在仓库根目录执行：

```sh
python3 -m http.server 51905 --bind 127.0.0.1 --directory apps/playground/prototypes/experience-redesign
```

打开 `http://localhost:51905/layout.html` 比较布局，打开 `http://localhost:51905/visual.html` 比较固定布局上的视觉方向。均支持 `?variant=A`、`B`、`C`。

## 已确认结论

- 布局选择 A：顶部阶段导航与固定属性面板。
- 视觉选择 C：双色品牌，靛蓝为主、珊瑚橙少量点缀。
- 首期需要浅色、深色主题与宿主视觉/密度/面板宽度定制。

本原型仅用于记录方案比较，不代表正式色值、尺寸、对比度、功能或第三方组件适配已通过验收。正式实现不得直接复制此原型充当生产代码。

本分支保留原始讨论来源，不合入产品分支。设计提案位于 `docs/experience-redesign` 分支的 `docs/design/2026-10-14-design-system-workbench-proposal.md`。
