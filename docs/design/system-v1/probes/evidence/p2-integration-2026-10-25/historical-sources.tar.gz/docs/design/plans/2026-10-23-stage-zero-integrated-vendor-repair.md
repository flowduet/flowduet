# 阶段零供应商整体修复执行计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking. 维护者已批准本计划并选择Native：本会话顺序实现，最后一次固定增量双轴审查；任务3已通过，当前继续任务4。

**Goal:** 在隔离副本中形成一个满足原阶段零完整合同的供应商适配候选，统一解决拖动、弹层、全局清理与卸载问题，并验证可随产物交付；不把局部通过当阶段零完成。

**Architecture:** 私有实例运行时集中管理owner/代际/资源，供应商适配通过小Interface接入；业务rules/options和输入缓冲仍由原模块持有。上游MIT固定原件与显式补丁生成私有适配模块，构建进隔离包产物，Vue/EP及原渲染器外置。

**Tech Stack:** 当前Node24.16.0、pnpm10.26.1；designer3.5.0、vuedraggable4.1.0、Sortable1.14.0、renderer3.3.4；实测Vue3.5.43/EP2.14.6；Vitest、Vite、vue-tsc、缓存Playwright CLI。

**Spec:** [已认可书面设计](../2026-10-23-stage-zero-integrated-vendor-repair-design.md)，来源提交`ee8f116`；本计划不扩设计§7范围。

当前执行状态（2026-10-23）：任务1、2、3完成。独立120分钟有界修复先取得自然null.top栈与5项RED，再只改获批三个实现文件；固定c5247ba的单元21/21、唯一35项G1全部通过，无页面异常。见[有界修复结果](../2026-10-23-bounded-g1-repair-result.md)。按此前批准继续任务4，再按门推进任务5–7；正式产品不改，旧作者修复1/1与新有界批次1/1均已消费，不增加后续修复轮。

历史STOP、额外纠正和60分钟结算保留在对应原件中，不再作为当前任务3状态。后续仍按原计划门禁，任何门失败/未知均不得标记阶段零完成。

## Global Constraints

- 维护者已认可设计、批准本计划并选择Native；任务1、2已执行，任务3已消费人类额外批准的一次初态纠正；计量纠正已获批且已消费，唯一作者修复已实施，当前回归释放click未获证并按失败即STOP停止，原正式产品边界保持。
- 保留八字段、栅格限制、三模式预览、全部当前开放属性/样式入口，原文/缺省/空串/0/false、同实例和同input生命期要求不降级。
- legacy未配置时保持body挂载默认及公开签名/业务行为；增强容器显式启用。宿主处理器覆盖和串实例副作用按缺陷修复，不刻意保留错误行为。
- 不改core/designer业务、FormManager保存/关闭/确认算法、Vue/EP/renderer内核；不引入Pro、第二业务模型、全局替代控件。
- 当前正式工作区只接收文档和固定源码/补丁归档。全部候选源码、安装、构建和本地pack发生在新隔离副本；原node_modules、依赖版本、lockfile、已冻结目录不变。
- 现peer Vue^3.5.0、EP^2.11.1保持；最低peer若不能验证则G5不通过，不静默缩窄。无推送、PR、合并、发布、发版或agent流程迁移。
- 原生与协议分列：OS IME、活动native中断、自然序列化ERR05未知仍阻断；自然Vue渲染异常不能补绿ERR05。
- 仅保留P2已批准的3项15秒例外；不改全局时限、不加重试、不以重复运行拼接成全量通过。

## Review Focus

1. 同formId在两个Document/两个app重建及非LIFO释放，旧owner不得影响新实例；由任务2、3的`old_owner_cannot_release_new_instance`和`inactive_destroy_keeps_active_drag`固定。
2. 宿主在挂载中途更新onbeforeunload/body.ondrop或已有自定义ElSelect，卸载不得恢复旧快照或覆盖组件；由任务2、5的`host_changes_survive_non_lifo_disposal`和`custom_host_components_survive_install`固定。
3. persistent弹层关闭后仍保留DOM，Escape应正常取消当前拖动；由任务4的`closed_popup_does_not_steal_escape`固定。
4. FileReader失败/abort/迟到load及用户取消选择，不得污染背景值或释放后的实例；由任务4的`late_image_read_keeps_replacement`固定，人工错误只计协议。
5. 独立包消费不继承仓库alias/patch，最低peer与模块来源不能被缓存掩盖；由任务5的`packed_consumer_uses_private_vendor`固定。

## 执行空间、源码和预算

### 唯一候选空间

在已附着的收敛工作区继续记录文档，不新开用户会话。实施时运行以下一次性初始化；它不是现在执行的命令：

```bash
REPO_ROOT="$(git rev-parse --show-toplevel)"
RUN_ROOT="$(mktemp -d "${TMPDIR%/}/flowduet-integrated.XXXXXX")"
mkdir "$RUN_ROOT/workspace" "$RUN_ROOT/evidence" "$RUN_ROOT/drivers"
git archive HEAD | tar -x -C "$RUN_ROOT/workspace"
```

把绝对RUN_ROOT、当前计划提交、产品基线`fcd715408579979240b8543cfbcab844c451436d`、Node/pnpm版本写入`$RUN_ROOT/evidence/run.json`，不复用旧goal指针。此后文中源码路径相对`$RUN_ROOT/workspace`，浏览器结果写`$RUN_ROOT/evidence`。不在原工作区安装或改源。

在副本运行`pnpm install --offline --frozen-lockfile --ignore-scripts`；安装后记录ignored脚本与原件哈希，不静默rebuild。缺缓存或缺必需安装脚本即停并报告准确对象，不换版本、不联网反复重试。随后副本`git init -b refactor/stage-zero-integrated-candidate`，提交未修改基线，记录`CANDIDATE_BASE=$(git rev-parse HEAD)`；该临时仓库无remote，实现按任务原子本地提交。

上游源码从当前锁定安装包的src/types/locale、ESM及LICENSE复制到`packages/form-create/vendor/upstream/{designer-3.5.0,vuedraggable-4.1.0,sortable-1.14.0}`；不从已有修订副本冒充上游原件。七类候选改动以已归档的固定增量有选择迁入，失败第八类不当基线。生成目录为`packages/form-create/vendor/generated`，只由原件+patch生成，不手工改第二份源码。

任务1另建`vendor/reference-seven`：从上述原件复制所需设计器/适配器，再按旧18项manifest覆盖其归档源码，作为只读七类负例。原始归档字节不改；旧绝对路径仅在新的Vite配置中重定向，重定向表和实际运行来源另行记录。reference与candidate配置分开缓存/端口，不能把正式P2副本或失败第八类误作G0的原负例。CANDIDATE_BASE仍取迁入任何候选代码前的镜像基线，最终差异包含旧七类的迁入和新修订，不只给审查者看最后几行。

### 文件责任

本文`integrated/`始终指`apps/playground/probes/stage-zero/integrated/`；internal模块和未带前缀的`*.test.ts`始终位于`packages/form-create/src/internal/`；vendor和scripts/build-vendor.mjs均属于`packages/form-create/`。原始browser驱动位于RUN_ROOT/drivers，单独纳入归档与审查。

- `packages/form-create/src/internal/editor-runtime.ts`：生命期、错误、全局listener/资源资格；`overlay-owner.ts`：容器/token/主题与owns；`vendor-entry.ts`：私有供应商入口。
- `packages/form-create/src/components/{FormDesigner,FormPreview,DateDefaultEditor}.vue`、`designer-config.ts`：消费上述Interface，保留既有输入和采集合同。
- `FormManager.vue`仅Dialog/确认框UI归属；`src/form-create-setup.ts`仅不覆盖宿主注册的一次装配。
- vendor原件不修改；`vendor/patches/{runtime,drag,overlays}.patch`承载设计§7列出的供应商SFC/声明、vuedraggable与Sortable修改。
- `packages/form-create/vendor/manifest.json`、`scripts/build-vendor.mjs`和副本`vite.config.ts`负责可复现构建；正式工作区对应文件不在本轮迁入。
- build-vendor和初始空patch由任务1建立，任务2–4修改补丁后调用它重新生成；任务5完成打包消费，不让前置任务等待尚不存在的生成入口。补丁可在`vendor/work`工作副本中编辑并导出，upstream/generated不手工编辑。
- 单元/组件回归在`packages/form-create/src/internal/*.test.ts`；直接浏览器驱动在`$RUN_ROOT/drivers/*.browser.js`，仅操作真实组件，不成为新监督框架。
- `packages/form-create/tsconfig.integrated.json`为严格入口；`apps/playground/probes/stage-zero/integrated/`包含本轮载体与库存。既有源文件只在副本改变。

临时副本的eslint.config.mjs/.prettierignore只增加vendor/upstream、reference-seven、work、generated四个明确的第三方目录；原件保持字节、补丁单独审查并由构建/运行验证，不能冒称这些第三方源码通过项目格式规则。自写internal、测试、载体和构建脚本仍接受原规则，strict入口不得扩大排除；正式工作区配置不改。浏览器原始驱动在workspace外做`node --check`后执行，按原件归档，不以它们干扰全量lint来制造工程失败。

`integrated/main.ts`按`case=g0|owner|overlays|host|resources|full`只挂一个载体：任务1建立g0，任务3增加DragOwnerProbe.vue，任务4增加OverlayProbe.vue，任务5增加HostConsumerProbe.vue/ResourcesProbe.vue，任务6增加FullContractProbe.vue。载体复用原FormRepair/Manager/Theme及资源夹具，保留同ID双实例；这些仅是临时入口，不引入新的产品或控制模型。

### 一个整体预算

- 一个新候选，不重开第八类失败实验。每任务预定RED、初次GREEN各一次；G0诊断最多9个fresh文档（3种overlay设置×3种切换形态），每组合一次。
- 真实GREEN或验收失败即停后续任务；整个候选最多保留**一次作者修复轮**，修复轮可一起处理已归因的确定问题，受影响定向与回归各复验一次。修复后再失败则STOP；这一次不能在最终审查时重复领取。
- 每任务最多一次驱动设置纠正，只限错误selector/错误初态/记录缺失；保留失败原件，不改产品断言或源合同来补绿。修采集器不允许无限补跑。
- 完整G4矩阵一次、G5消费/资源矩阵一次、G6四命令各一次。修复轮未使用且发现确定问题时，可用于一次修复及受影响复验；不得把多次部分成功拼成一次完整成功。
- 一次固定增量Standards/Spec审查；不为每个文件或任务重复启动整分支审查。独立发现使用同一作者修复轮，不能增加第二轮。
- 人工OS动作不设作答期限；新输入、配置选择和真实异常缺证不自动跳过。机器运行的观察超时不代表进程终止，继续核对原handle，不能据此重启。

## 共享Interface（任务2定义，其他任务不得改名）

```ts
type DragRef = Readonly<{ instance: symbol; engine: symbol; generation: number; sequence: number }>;
type CancelReceipt =
  | { status: "confirmed"; ref: DragRef }
  | { status: "blocked"; ref: DragRef; reason: string }
  | { status: "rejected"; reason: "stale" | "foreign" | "unsupported" };
type DisposeReceipt = { status: "disposed" } | { status: "blocked"; reason: string };
type RuntimeSnapshot = Readonly<{
  phase: "ready" | "cancelling" | "disposing" | "faulted" | "disposed";
  generation: number;
  canCapture: boolean;
  reason?: string;
}>;
type RuntimePort = {
  read(): RuntimeSnapshot;
  owns(target: EventTarget | null): boolean;
  requestCancel(ref: DragRef): Promise<CancelReceipt>;
  dispose(): Promise<DisposeReceipt>;
};
type OverlayKind = "select" | "color" | "date" | "dropdown" | "tooltip" | "dialog";
type OverlayOwner = {
  propsFor(
    kind: OverlayKind,
    explicit: Readonly<Record<string, unknown>>,
  ): Readonly<Record<string, unknown>>;
  owns(target: EventTarget | null): boolean;
  dispose(): DisposeReceipt;
};
```

`createOverlayOwner({instance,contentRoot,overlayRoot?,themeRoot?}):OverlayOwner`在overlay-owner.ts；`createInstanceRuntime({instance,contentRoot,overlay,cancel,dirty,exitConfirm,reportFault,lifecycle}):RuntimePort`在editor-runtime.ts。instance为symbol，根节点均为HTMLElement；cancel为`(ref:DragRef)=>Promise<CancelReceipt>`；dirty为`()=>boolean`，reportFault为`(error:unknown)=>void`，exitConfirm为boolean。`lifecycle`为私有依赖`{whenUnmounted:Promise<void>;subscribeFault(listener:(error:unknown)=>void):()=>void}`，由宿主真实onUnmounted/errorCaptured桥接，不从DOM消失推定Vue已卸载。FormDesigner将runtime非ready映射到既有`not-ready`/`disposed`屏障，不扩公共blocker枚举或API。

`createDragCoordinator(document:Document)`由任务3定义，返回`begin({instance,engine,backend}):DragRef|null`、`read():DragRef|null`、`cancel(ref):Promise<CancelReceipt>`、`releaseEngine(engine:symbol):Promise<DisposeReceipt>`；backend为`"native"|"fallback"`。资源/DOM捕获由适配器内部注册，包装层不调用私有Sortable方法。

同一coordinator还提供`registerEngine({instance:symbol,engine:symbol,backend,cancelOwnedDrag:(ref:DragRef)=>Promise<CancelReceipt>,releaseOwnResources:()=>Promise<DisposeReceipt>}):()=>void`。vuedraggable在引擎创建时注册、销毁时按返回资格注销；只有注册且归属匹配的引擎可begin。cancel/release调用该引擎自己的适配后公开方法；闭包中的DOM/资源不暴露到包装层。注销旧engine不能删除新engine登记，非活动engine也可独立释放。

---

### Task 1: 固定输入并归因自然渲染异常（G0诊断）

**Files:** Create `integrated/{index.html,main.ts,vite.config.ts,RenderLifecycleProbe.vue}`与`$RUN_ROOT/drivers/g0.browser.js`，前缀为`apps/playground/probes/stage-zero/`；Create `packages/form-create/scripts/build-vendor.mjs`及vendor原件/manifest/空patch/reference-seven；产出`$RUN_ROOT/evidence/g0-attribution.json`。

**Interfaces:** Consumes既有公开read/capture/export和18项manifest。Produces `{owner:"carrier"|"designer"|"adapter"|"unknown",sourceFile:string,firstFailure:string,variants:readonly object[],sourceValidated:boolean}`；sourceFile必须属于设计§7，owner=unknown不能继续。`build-vendor.mjs`无参数，从本包vendor/upstream和patches生成generated；patch/哈希不匹配退出非0。Vite mode=reference使用只读七类，mode=candidate使用当前私有适配；只供探针，消费测试不使用此alias。

- [x] **Step 1:** 完成一次性空间/安装/基线设置；核对设计来源JSON和全部18项旧输入。给Theme载体和FormDesigner后代分别设置自有errorCaptured观察点，记录首异常前后生命期，不覆盖app错误处理器、不人工throw。
- [x] **Step 2:** 实现9格直接驱动：overlay为无适配/旧桥接/独立容器，切换为仅designer/仅preview/往返；每格fresh文档。记录error原件、DOM数量、两份完整内容、原文/input引用和公开状态。原始负例的断言是：

```js
assert(report.sourceValidated);
assert(report.original.errors.some((e) => e.message.includes("insertBefore")));
assert(report.original.after.designers !== 0 || report.original.after.errors.length > 0);
```

- [x] **Step 3:** Run：在副本启动`pnpm --filter @flowduet/playground exec vite --config probes/stage-zero/integrated/vite.config.ts --mode reference --host 127.0.0.1 --port 5201 --strictPort`，使用已缓存CLI `npx --offline --package @playwright/cli playwright-cli -s=flowduet-integrated-g0 open http://127.0.0.1:5201/probes/stage-zero/integrated/index.html --browser chrome`，再用同一完整CLI前缀执行`run-code --filename "$RUN_ROOT/drivers/g0.browser.js"`。Expected：取得真实原负例及有来源的归因；加载错误不计产品RED。
- [x] **Step 4:** 根据首事件/组件边界和因果对照形成g0-attribution.json；不能归因或需改Vue/EP/renderer内核则STOP。此任务只交付诊断，不假定某一改法已修复；GREEN由任务2完成。
- [x] **Step 5:** 在临时仓库提交`test(probe): 固定卸载首异常与所有权归因`，把源码与原件索引记入evidence/ledger.md；不重复冻结整个旧证据包。

### Task 2: 实例运行时、独立容器与错误/全局资源（G0 GREEN、G3基础）

**Files:** Create上述3个internal模块、`editor-runtime.test.ts`、`overlay-owner.test.ts`；Modify副本FormDesigner/FormPreview、必要的载体、vendor/runtime.patch；Create `$RUN_ROOT/drivers/runtime.browser.js`。

**Interfaces:** Consumes任务1归因；Produces共享RuntimePort/OverlayOwner及FormDesigner既有状态屏障。内部错误资格通过工厂闭包处理，不新增公共方法。

- [x] **Step 1:** 写`faulted_editor_never_reports_capture_ready`、`host_changes_survive_non_lifo_disposal`、`old_owner_cannot_release_new_instance`和真实g0恢复断言：

```ts
expect(oldPort.read().canCapture).toBe(false);
expect(currentHostHandler).toBe(replacementHostHandler);
expect(newPort.read().phase).toBe("ready");
```

- [x] **Step 2:** Run `pnpm --filter @flowduet/form-create exec vitest run src/internal/editor-runtime.test.ts src/internal/overlay-owner.test.ts`。Expected：新合同未实现的RED独立记录；真实产品缺陷RED只引用任务1实测，模块导入错误不冒充该缺陷。
- [x] **Step 3:** 实现共享工厂并按旧归档差异迁入所需七类能力，入口`vendor-entry.ts`指向generated；容器由Vue声明，样式节点独立放head；只处理任务1归因对应的设计内源。beforeunload采用可移除listener、drop限定自有根，绝不写单槽handler；组件/载体错误各自经lifecycle订阅撤销自身健康资格并向宿主报告。onBeforeUnmount启动dispose并消费其结果，不阻塞Vue销毁；真实onUnmounted才兑现whenUnmounted，资源未释放或失败时保持blocked且可重试，重复完成幂等。更新patch后运行`node packages/form-create/scripts/build-vendor.mjs`，不手改generated。
- [x] **Step 4:** 同单元命令GREEN；另启动相同Vite配置`--mode candidate --port 5202`，用会话`flowduet-integrated-candidate`打开5202入口。此后所有候选browser脚本统一通过`npx --offline --package @playwright/cli playwright-cli -s=flowduet-integrated-candidate run-code --filename "$RUN_ROOT/drivers/<本任务文件名>"`运行；文件名逐任务明确，原版仍用5201。`runtime.browser.js`重放任务1首失败轨迹及0→2→0、非LIFO、宿主中途更新handler、两个Document同formId。Expected：无自然渲染错误、完全卸载、handler身份保持、旧owner不能释放新owner；失败使用整体STOP/修复轮，不继续后续门。
- [x] **Step 5:** 临时仓库提交`fix(probe): 收拢实例资源与卸载错误资格`，登记G0/G3基础结果。

### Task 3: 稳定拖动owner与确定取消（G1）

**Files:** Create `src/internal/drag-coordinator.ts`、`drag-coordinator.test.ts`、`integrated/DragOwnerProbe.vue`、`$RUN_ROOT/drivers/drag-owner.browser.js`；Modify vendor/drag.patch中的Sortable ESM、vuedraggable源码/声明、DragBox与FormDesigner接线。

**Interfaces:** Consumes RuntimePort、DragRef、CancelReceipt；Produces createDragCoordinator。begin在准备阶段签发稳定ref，第二owner活动时返回null；不同Document独立。

- [x] **Step 1:** 写`inactive_destroy_keeps_active_drag`、`cancel_rejects_late_generation`、`cancel_confirms_only_after_owned_cleanup`；浏览器原版负例必须验证B首击未打开，候选目标为首击打开。协议断言：

```ts
expect(coordinator.read()).toBe(activeA);
expect(await coordinator.cancel(staleA)).toEqual({ status: "rejected", reason: "stale" });
expect(businessCommits).toBe(0);
```

- [x] **Step 2:** Run `pnpm --filter @flowduet/form-create exec vitest run src/internal/drag-coordinator.test.ts`和驱动的原版模式一次。Expected：稳定owner合同RED及真实首击负例，不重跑失败第八类来扩大其预算。
- [x] **Step 3:** 实现事务记录、按owner的销毁/插件/自动滚动/点击屏障释放；非owner不调用结束他人事务的路径。包装层仅调用适配公开取消Interface，先撤销旧代提交，精确恢复DOM/锚点；原文/input不重建。native主动取消未证明时返回unsupported。
- [x] **Step 4:** 同命令及`drag-owner.browser.js`候选模式GREEN；A活动时在前/中/后销毁B、API/Escape取消、重复/旧ref/迟到事件、活动卸载与首击、原文ASCII `-`/日期`2026-`/显式空串、同input/节点与底层资源配对。Expected：零取消提交、旁实例保持，正常drop防误触与取消后的正常首击分别通过；源锚点丢失须blocked。
- [x] **Step 5:** 临时仓库提交`fix(probe): 明确拖动事务所有权与取消收据`。

### Task 4: 全弹层与预览、确认框和文件读取（G2、G3 owner）

**Files:** Modify overlay-owner.ts、designer-config.ts、DateDefaultEditor、FormPreview和FormManager UI接缝；vendor/overlays.patch覆盖设计§7列出的直接SFC/样式组件；Create `overlay-rules.test.ts`、`image-read-lifetime.test.ts`、`integrated/OverlayProbe.vue`、`integrated/overlay-inventory.json`、`$RUN_ROOT/drivers/overlays.browser.js`。

**Interfaces:** Consumes OverlayOwner.propsFor/owns和runtime资格；Produces `decorateUiRules(rules:readonly unknown[],owner:OverlayOwner):readonly unknown[]`，仅作用于UI配置/渲染派生规则，原字符串不变。

- [x] **Step 1:** 写`ui_overlay_props_never_enter_business_content`、`closed_popup_does_not_steal_escape`、`late_image_read_keeps_replacement`；固定业务语义断言：

```ts
expect(exportedAfter).toEqual(exportedBefore);
expect(unsetRule).not.toHaveProperty("value");
expect(values).toEqual(["", 0, false]);
expect(replacementBackground).toBe(originalReplacementBackground);
```

- [x] **Step 2:** Run `pnpm --filter @flowduet/form-create exec vitest run src/internal/overlay-rules.test.ts src/internal/image-read-lifetime.test.ts`，驱动原版22颜色路径作为真实RED；不把协议FileReader失败计为自然ERR05。
- [ ] **Step 3:** 接入生成的base/props/form/default/control配置、ValueInput/ColorInput及所有列出样式弹层，显式props优先；日期用已核对能力或owner桥接。Manager只补session所属容器/customClass；背景读取处理error/abort/迟到load，保持既有背景值和事件语义。
- [ ] **Step 4:** 为设计§5.3每个可达入口填稳定id、触发步骤、控件/容器、owner来源、关闭条件、主题/焦点/快捷键断言；不可达项有配置及UI证据。GREEN运行同单元命令与`overlays.browser.js`：两实例×浅深×两密度、交换/开关/重挂、nested/persistent、滚动/遮罩、三预览入口和生成组件/HTML。Expected：可达项无unknown owner、宿主/peer保持、内容不混入UI参数、关闭后Escape可用；系统文件框单列OS限制，不以隐藏入口通过。
- [ ] **Step 5:** 临时仓库提交`fix(probe): 统一弹层归属与预览派生规则`；库存有未覆盖入口则不进入下一门。

### Task 5: 宿主装配、可消费产物及资源（G3、G5）

**Files:** Modify副本form-create-setup.ts、vite.config.ts及任务1生成入口/manifest；Create `src/internal/vendor-pack.test.ts`、`integrated/HostConsumerProbe.vue`、`integrated/ResourcesProbe.vue`、`$RUN_ROOT/drivers/host.browser.js`、`$RUN_ROOT/drivers/resources.browser.js`、`$RUN_ROOT/consumer/`。

**Interfaces:** Consumes前四任务的唯一候选；Produces私有vendor-entry及带来源/许可证的本地tgz。build-vendor从upstream+patch生成，失败不得回落原版。

- [ ] **Step 1:** 写`custom_host_components_survive_install`及`packed_consumer_uses_private_vendor`：宿主自定义ElSelect身份、app错误处理器和动态handler保持；产物不依赖workspace alias/根patch，缺patch或哈希漂移必须失败。
- [ ] **Step 2:** 将CANDIDATE_BASE只读导出到`$RUN_ROOT/consumer-baseline-source`，离线锁定安装后仅一次`pnpm build`和本地pack，建立原包真实consumer；这次原基线build/pack是消费RED对照，不记作最终候选四命令。`vendor-pack.test.ts`先针对该实际包跑，验证其Escape取消/实际模块来源不满足新合同；不能拿缺tgz、缺依赖或静态external配置文本充当产品RED。原基线准备失败则停止，不修原P2来迁就新测试。
- [ ] **Step 3:** 实现固定原件+显式patch生成和私有构建，保留LICENSE/NOTICE；仅在副本把私有供应商打入dist，Vue/EP/renderer外置。装配只补缺失的必需注册，不全局代理控件或覆盖宿主；pack不发布、不改原lock。
- [ ] **Step 4:** Run `pnpm --filter @flowduet/form-create build`及`pnpm --filter @flowduet/form-create pack --pack-destination "$RUN_ROOT/evidence"`；创建无workspace/alias/根patch的consumer。用`pnpm --dir "$RUN_ROOT/consumer" install --offline --ignore-scripts`安装明确版本的Vue/EP/renderer及本地tgz；core/designer也本地pack，必要工作区传递依赖须全部使用对应本地产物，依赖树不得连回源码工作区。consumer的实际包名/哈希写入manifest后，运行`pnpm --filter @flowduet/form-create exec vitest run src/internal/vendor-pack.test.ts`及真实consumer UI驱动。分别验证Vue3.5.0/EP2.11.1与Vue3.5.43/EP2.14.6，renderer固定3.3.4。缺最低版本缓存则记录G5未验证，不下载换版本凑数；不能据此宣称整个peer区间已认证。
- [ ] **Step 5:** `host.browser.js`实际Ctrl和Cmd+S分别在两个实例、各自所有可聚焦弹层及宿主控件取证，检查无适配器隐藏/不可用。`resources.browser.js`按2/10/20、两轮挂载/20次切换/卸载、1秒/3秒GC和原容器样本收集；记录产物体积与来源模块图，不制造预算阈值。Expected：请求只归焦点owner，旧返回不确认新输入，正式候选资源与旧基线分列。
- [ ] **Step 6:** 临时仓库提交`build(probe): 验证私有供应商产物与独立消费`；许可、来源、消费或资源缺证即不通过。

### Task 6: 完整业务与真实环境（G4）

**Files:** Create `$RUN_ROOT/drivers/full-contract.browser.js`、`integrated/FullContractProbe.vue`、`integrated/v01-record.json`；复用既有输入/拖动/Manager与人工观察器，修订载体不得改变产品合同。

**Interfaces:** Consumes同一最终候选、完整库存及[原B03合同](../2026-10-16-b03-minimal-production-fixes-proposal.md)；Produces每一适用N/T/D/H/M/V行的真实/协议/未知状态和原件链接。

- [ ] **Step 1:** 将原B03行、菜单八字段两布局三轮API/Escape的96条、16种正常对照、36条中间原文、排序/跨列、Manager M04–M08、legacy缺省/显式对照逐项排入直接驱动；保留原D03直接移出与附加先入后出两类轨迹，不改成功定义。
- [ ] **Step 2:** `full-contract.browser.js`一次完整运行，断言取消零提交、原文/值存在性和同input/字段保持、同实例再拖、迟到旧owner拒绝、确认/保存各一次且非持久化回执。示例：

```js
assert(row.raw === "-");
assert(row.sameInput && row.sameWidget && row.cancelCommits === 0);
assert(row.peerBefore === row.peerAfter && row.dialogs === 1);
```

- [ ] **Step 3:** 本会话准备固定来源的可见Chrome及只读观察器，维护者按[V01人工步骤](../system-v1/probes/v01-manual-verification-2026-10-23.md)操作，本会话读回真实事件/状态；活动native中断和自然序列化ERR05独立留证。不制造事件或人为异常，不要求用户无限随机复现。
- [ ] **Step 4:** 所有适用行均有同源充分证据才GREEN；OS/active-native/ERR05仍未知或任一已知失败则任务未完成，保留原件并停止最终完成声明。没有自动人工答复期限，也不反复重放已证普通路径。
- [ ] **Step 5:** 临时仓库提交`test(probe): 记录完整业务与原生验证边界`；失败也可原子提交证据，但不得把任务勾为通过。

### Task 7: 一次最终门、固定审查与阶段出口（G6）

**Files:** Create `packages/form-create/tsconfig.integrated.json`；最终归档写回原收敛工作区`docs/design/system-v1/probes/evidence/stage-zero-integrated-2026-10-23/`；更新原35项审计与收敛报告。

**Interfaces:** Consumes任务1–6的同一候选与CANDIDATE_BASE；Produces完整patch/manifest、四命令原件、一次独立审查及维护者可复核的出口裁定。

- [ ] **Step 1:** tsconfig继承原strict配置，paths指向副本实际core/designer源，include本轮wrapper/internal/载体/声明及原严格fixture；不使用假声明、宽化或全局排除。归档最终文件哈希后，原样运行四命令：

```bash
pnpm test
pnpm build
pnpm lint
pnpm --filter @flowduet/form-create exec vue-tsc --noEmit -p "$RUN_ROOT/workspace/packages/form-create/tsconfig.integrated.json"
```

Expected：四项各退出0；默认根逐包计数来自同一次完整运行，不预填“950”作为新候选固定总数。供应商JS由构建/真实路径验证，不冒称strict覆盖；Node22/24远端CI未运行则明确记未运行。

- [ ] **Step 2:** 在临时仓库固定HEAD、`git diff "$CANDIDATE_BASE"..HEAD`和全部输入哈希，做一次Standards/Spec独立审查。根据已用预算决定是否还能使用一次作者修复轮；没有第二次整分支审查或额外修复预算。
- [ ] **Step 3:** 原35项、全部B03行、G0–G6逐条核对原件和源码；不能由manifest/verifier或绿命令推出未覆盖要求。正式P2与新候选、模拟/真实/OS、失败/未测分列。
- [ ] **Step 4:** 把原件、许可证、上游来源、统一patch、构建/消费命令与模块图、已测/未测/失败及责任归档到原工作区，保持原产品零差异；提交`docs(design): 汇总整体候选验证与阶段零出口`。原临时仓库的原子提交哈希和变更一并可恢复。
- [ ] **Step 5:** 仅关闭已核对身份的本轮浏览器和服务；归档可恢复后再清临时空间，不误杀旧5191/5195等服务。完整目标真已满足才调用goal complete；任何门失败/未知则不完成，明确用户唯一必要决定或操作。最终由维护者按任务6.5审阅，不自动正式迁入、推送或进入阶段一。

## 本轮计划自审与实施交接

已逐节映射设计：§3/6→任务2，§4→任务3，§5→任务4，§8→任务5，§9→任务6/7，未知根因→任务1；五项Review Focus均有归属测试。共享类型/函数名在全任务保持，公共blocker枚举不扩；安装/pack只在副本，正式构建迁入不混入本次批准。

本计划有前置诊断门，不预编造尚未知的Vue修法；若任务1不能给出设计内的可证归因，后续实施停止而非猜补丁。计划中的新脚本/测试尚未创建或运行，所有Expected都是未来验收条件。

建议Native执行，因为任务2–5共享owner、overlay与供应商生成结果；最后进行一次双轴独立审查。维护者已批准并选择Native；后续前置/计量纠正、作者修复及60分钟最小收敛均已有明确批准并执行。最新有界G1修复已通过，本会话继续任务4，不依赖后台自动完成；不再把历史待审批状态作为当前状态。

当前停片补记：任务4初次实现的单元7/7，完整浏览器因h3定位歧义在0行停止；唯一记录纠正已用，未补跑。任务4未通过，任务5–7未启动。恢复、责任、未应用三行纠正提案见[任务4恢复停片](../2026-10-23-task4-recovery-stop.md)。该状态取代上文“继续任务4”的执行状态，不改历史G1结论。

三行纠正补记：用户额外批准后仅应用固定三行补丁并单次复验；53条局部记录后在show-tooltip=false滑块等待提示超时，按约定STOP。产品候选1d6fe467未改、未补跑，任务4未通过，任务5–7未启动；[单次结果及测量缺口](../2026-10-23-task4-selector-correction-result.md)为最新执行状态。

2026-10-24最新状态：统一测量修订限定五个测量文件，11项协议及限定lint通过；唯一正式运行4条局部通过，第5条因外层Popper必须有id的新驱动假设而测量失效，按授权STOP，未修订或补跑。113个库存条目不是已验数量，任务4仍未通过、任务5–7未启动。见[统一修订结算](../2026-10-24-task4-unified-result.md)。
