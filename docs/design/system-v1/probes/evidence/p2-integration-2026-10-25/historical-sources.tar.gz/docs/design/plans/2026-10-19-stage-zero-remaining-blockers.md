# 阶段零剩余阻断薄切片计划

**2026-10-19 B2授权/结果：** 维护者确认B1有效，明确CPU使用waitedChildCPUSeconds与sumMaxObservedPIDCPUSeconds并记录退出RSS/CPU双零，不用last退零否决；只授权剩余B2一次。实际[B2默认300/300并通过观察门](../system-v1/probes/b03-p2-t1-b2-screen.md)，累计2/2用完，T1筛选完成；旧B1记录/STOP不改、正式源不改、T2未授权。下方旧CPU终值/停止描述按原时点保留，不覆盖本次明确修订。

**2026-10-19 T1执行追加：** 审阅后用户仅追加授权T1最多两次/tmp候选默认包命令及自有树RSS/CPU。实际[B1默认300/300、资源后审STOP](../system-v1/probes/b03-p2-t1-fixture-screen.md)，未启动B2、不改正式源。下文各旧“未授权T1/本轮仅文档”为其时点记录，不构成自动续跑；P3/D0保持blocked。

**2026-10-19执行追加：** 用户仅批准Q0与T0静态执行；两片结果见[本批记录](../system-v1/probes/q0-t0-2026-10-19.md)。Q0的P3/D公开能力门保持受阻，T0完成原143身份/依赖映射；D0/T1及产品修改未授权、未执行。下方提案时点的“待审阅/本轮仅文档”原文保留，不作为重复授权或自动启动依据。

> 状态：待审阅，本轮只编写文档；所有复选框均为未来工作。批准本文件不等于批准供应商补丁、外置预览产品替换或正式测试重组。
>
> **For agentic workers:** 获明确分片授权后使用 `superpowers:executing-plans` 在本会话逐片执行；批末一次独立Standards/Spec复核。复选框表示实际完成，不预勾。用户约定的命令预算/停片门优先于技能通用重跑循环。

**Goal:** 先用Q0/T0静态成果锁定可实施范围，再按新授权筛选D候选或P2夹具，P3只在公开能力成立后进入探针。

**Architecture:** 三组分开记录来源、接口与验收；Playground仍是唯一完整集成宿主，候选放/tmp镜像；正式产品/测试变更需候选证据和后续准确方案获审。本计划不启动P4、E或正式工作台。

**Tech Stack:** 当前锁定Node24.16.0、pnpm10.26.1、Vue、Element Plus、FormCreate设计器3.5.0及现有浏览器工具；不安装新依赖。

**Spec:** [剩余阻断最小处置提案](../2026-10-19-stage-zero-remaining-blockers-proposal.md)，并保留[原编辑合同](../2026-10-15-stage-zero-editing-contract.md)、[B03原修复计划](2026-10-16-b03-minimal-production-fixes.md)及[联合批次原矩阵](2026-10-19-stage-zero-cd-batch.md)。

## Global Constraints

- 本轮授权仅文档，不运行下面任何命令、测试、浏览器、采样或实验；不改产品/测试/config/依赖/lockfile/CI，不推送。
- 冻结本地 `refactor/b03-retained-text-defaults@098d685` 的239项正式非设计文档文件；候选的允许差异单列，禁止把源码变化混入旧冻结基线。
- legacy默认、显式retained、K、字段生命期、同步捕获、真实组件、全部原动作断言/字段配置/CSS取舍/默认5秒及既有15秒不变；不采用R。
- 不动原8项清单或旧STOP；本计划的T1是新候选正确性筛选，不是G-M续跑，不追认旧准入通过，不声称配对收益。
- 不访问私有VM/Sortable，不用setRule、改key、重挂或替换文档取消拖动，不改变引擎/文档合同、公开barrel或启用Pro。
- APP-T、既存宽目录类型、OS/native/ERR05、P4及B01/B03/B04维持各自证据边界；品牌与设计系统继续独立。
- 静态/协议/真实UI/自然故障分层；供应商src/dist哈希不等于实际浏览器加载；资源不能跨轮拼峰值或用GC时长倒推通过。

## Review Focus

1. 隐藏预览按钮后BODY快捷键仍开启旧Dialog，或双实例一起响应——归Q0/D0的V01。
2. 待确认数值/日期、显式空串/未设置及同ID新生命期被旧快照覆盖——归D0的V02/V03。
3. 试填校验Promise在关闭/替换后回写新会话，或popup挂载越过实例根——归D0的V03/V04/V05；不可真实复现保留未知。
4. 测试夹具模块单例、hook副作用、旧finally或样式恢复串入另一文件/例——归T0/T1，保留全部原恢复断言。
5. 新文件漏掉it.each参数/改了主CSS或时限，局部收益掩盖包级失败——归T0目录映射、T1整包与T2正式验证门。

## 授权与依赖门

建议下一次仅授权Q0+T0：两者只产出文档/映射，不运行实验或改测试。Q0若给出公开能力证据，再另审D0或P3门探针；T0映射获审，再明确授权T1。允许维护者在事实充分时一次批准明确的后续切片，避免机械逐步请示，但不能把当前文档授权当成这些批准。

三组之间不因某组门红自动否定另一个已单独批准的静态工作；运行期间任意超时、未处理拒绝、恢复失败、来源漂移或无法证明隔离则停止该获准运行批次，不由代理自行改成静态blocked继续。进入另一运行批次必须有明确授权和隔离证明。

## Q0：P3/D公开合同与兼容取舍（建议首批）

**Files:** 新增 `docs/design/system-v1/probes/b03-drag-public-contract.md`、`preview-entry-contract.md`，仅追加现有两份门报告索引；不改安装包或产品。

**Interfaces:** 消费供应商实际版本、Config/Handle/公开方法与安装包对应源码；产出 `PublicSeamRecord = { capability, actualName, signature, version, authority, sourceRef, paths, status, reason }` 的文档表。status为documented/insufficient/unverified，不能仅用源码存在判documented。

- [ ] 固定完整HEAD、239源SHA、lockfile/依赖身份和旧证据入口；文档新增不更换正式源。
- [ ] 合并核实四路径取消请求/结束/提交前拒绝、预览按钮/快捷键/程序入口及实例定向挂载。已核对安装包部分只引用，不再重复探索私有对象。
- [ ] 若本地公开材料不足，未来授权可只读官方仓库/文档最多8个页面、每页单次获取≤15秒；不安装、不拉整库、不更新依赖、不向供应商发消息。访问失败记unknown，不重复网络追查。
- [ ] 公共声明、版本锁定说明/测试与实际入口不一致即列精确缺口；较新版本候选仅登记升级影响，不能换依赖继续。
- [ ] 对D明确：外置主体只提供现有试填/校验；供应商表单/组件代码/HTML及复制/重置逐项列保留/差异，不隐含用户同意减少能力。按钮隐藏、Ctrl/Cmd+P和多实例归属分别核对。
- [ ] 交付P3所需接缝需求表与D入口选择表；没有受支持通道就blocked并停止该路线，不运行浏览器。需要补丁/新增公开props或禁用快捷键/粘贴则写另审范围。

**Verification:** 仅源码/引用/版本/链接静态核对；无测试命令。通过条件是合同事实可追溯及“可进候选/缺能力需裁定”准确，不要求能力必然存在。

## T0：原143项的静态拆分与夹具依赖表（建议首批）

**Files:** 新增 `docs/design/system-v1/probes/b03-p2-fixture-partition.md` 及同名证据目录中的 `registration-map.json`、`fixture-dependencies.json`；只有数据，不生成或执行候选代码。

**Interfaces:** 消费 `src/components.test.ts@098d685` 和旧完整300目录；产出每条原64注册语句的原范围/原SHA、展开参数、目标文件/顺序、依赖、CSS/timeout合同。每个原展开测试恰有一归属，合计143；独立文字28与其他129保持。

- [ ] 用现有TypeScript静态解析器读取注册/fixture，不调用vitest收集或执行测试。
- [ ] 依据规格§5.2划分legacy原文件、retained-inputs与retained-manager；嵌套describe连同其局部hook作为单元，不拆其原before/afterEach顺序。
- [ ] 枚举声明闭包依赖，明确哪些常量/函数进每文件私有工厂，哪些hook留在原describe；禁止公共可变单例或自动注册hook的导入副作用。
- [ ] 私有工厂拟用文件局部`wrapper`/`originalElementString`的get/set接线，保留所有owner/spies/style/gate原逻辑；将每个调用/原清理时序映射到目标模块，不先优化等待或卸载。
- [ ] 逐一列入本轮delete超时、旧finally超时、原14哨兵和既有未传选项/legacy保留CSS路径；映射不到或需要改变业务正文则停止并提出最小差异。
- [ ] 校验原64注册和全部参数/时限/CSS字段、143+28+129=300，没有遗漏/重复。数据不足时明确停在映射，不用旧目录假装已动态验证新组织。

**Verification:** 静态映射/SHA/引用与重复性检查；不得运行list/collect/test。输出由维护者审阅，尚不授权T1或正式落库。

## D0：外置预览条件性镜像候选（另行授权）

**Files:** 只在新/tmp Playground镜像修改 `apps/playground/probes/stage-zero/ThemeIsolationProbe.vue`，新增 `theme-surfaces.ts`、最小 `ProbeApp.vue` 导航；不改三个产品包、FormPreview或供应商。源文本归档于新 `preview-ownership-candidate` 证据目录。

**Interfaces:** 消费Q0确认的公开入口定向合同及既有 `readEditingState(): FormDesignerEditingState`、`captureContent(): FormDesignerCaptureResult`；私有PreviewTicket按规格§4.2。prod props/events无本批产出。

- [ ] 仅在Q0全部必需入口公开可控且维护者确认候选能力差异后开始；否则跳过D0保持blocked。
- [ ] 先按V01核对候选按钮/快捷键/程序入口和另一实例。每项必须指明公开配置/事件，不能用全局监听或未声明hotKey开关；最多6条动作轨迹，第一处缺口即停。
- [ ] 复用capture结果创建新FormDefinition，挂入实例拥有的局部容器；busy/failed/过时ticket不打开，未保存session。源规则/配置副本与保存内容分别哈希。
- [ ] V02最多14条（七状态×双实例）、V03最多6条（表单切换/同ID换代/文档替换×双实例）；逐条保存原文/存在性/生命期/版本与跨实例状态，未能捕获时不强制导出。
- [ ] V04最多8条轨迹：解析失败、校验失败、关闭/重开、卸载各双实例。使用真实公开入口；自然同步throw/迟到Promise无法触发时记未验证，不为填表加私有故障口或冒充ERR05。任何真实未处理拒绝/恢复错误立即STOP。
- [ ] 所有必需surface归属证明后，才运行原128字段基线及9关键序列，保留打开/关闭、焦点/错误/禁用和4.5:1/3:1标准。不可达项列依据，不能把未知改N/A。
- [ ] 归档加载模块实际URL/内容SHA、镜像源差异、状态/样式/截图与未运行项。新路径通过仅支持产品接缝提案；默认供应商路径旧阻断不删除。

**Command budget:** 镜像严格probe类型最多2次，第二次仅允许一次语法/接线修正后复查；Vite一次；不额外unit/build/lint/宽类型。V01–V04合计最多34条，每条≤30秒，不补轮；任一必需归属门失败停止扩展。原128/9是条件矩阵，不得绕过前门。

```sh
pnpm --filter @flowduet/form-create exec vue-tsc --noEmit -p ../../apps/playground/probes/stage-zero/tsconfig.json
pnpm --filter @flowduet/playground exec vite --config probes/stage-zero/vite.config.ts --host 127.0.0.1
```

未来若确实需生产props/events或FormPreview校验会话修复，停止候选提交另外的准确文件/API/回归方案，不在本片边做边扩。

## T1：测试组织候选先行筛选（另行授权）

**Files:** 新/tmp镜像中只允许T0四个测试位置的变化：原 `src/components.test.ts`，新 `components/retained-inputs.test.ts`、`components/retained-manager.test.ts`、`components/__tests__/component-test-fixture.ts`。另外28+129测试、产品/config/依赖保持，不新增产品测试口。

**Interfaces:** 消费获审T0完整映射；工厂每文件调用一次，接受`getWrapper()/setWrapper(value)`、`getOriginalElementString()/setOriginalElementString(value)`。产出原同名fixture函数/常量及显式beforeEach/afterEach调用口；owner、root、spy、gate、style全为该工厂闭包状态，导入无副作用。准确TypeScript辅助类型由T0依赖表列全，再允许构造；正文不需任何变动。

- [ ] 按T0映射机械迁移，原测试正文/参数/动作/断言/原时限逐字还原一致；hook迁移按原作用域核对。不能为编译方便削弱类型/断言或用空stub代替真实fixture。
- [ ] 镜像只加载各文件私有工厂；每例兼容描述符快照、登记、先失效/逆序关闭、第一异常及旧finally保护按原逻辑保持。主CSS只按原显式选项移离，不改变默认。
- [ ] 静态验明143+28+129不变、与原登记表一对一、其他239来源排除明确候选测试文件后无漂移；不额外跑收集命令。
- [ ] 资源预检只采自有命令树PID/RSS/CPU时间与原进程归属。不得扩大到其他进程/系统信息，沿用必要权限需在新授权中明确；不可用即停，不自动扩权。
- [ ] B1在独立镜像/私有空缓存执行下列包默认命令一次，同时保留完整输出、退出码、实际300计数、原清理断言及数值采样。外部采样不修改测试正文/钩子，不增加堆/GC插桩。
- [ ] B1任意超时/失败/未处理拒绝/恢复或采样缺口立即停止；只有300/300且所有门满足，才在第二独立同源镜像执行B2一次。B2同门；不预热、不移动mount、不追加第三轮。
- [ ] 记录两轮墙钟、命令树RSS/CPU、目录/来源与退出；把历史高堆和默认游走超时原样保留。没有A/B配对，无新堆/GC归属，不能声称拆分造成收益、唯一根因已修复或资源预算接受。

```sh
pnpm --filter @flowduet/form-create test
```

**Budget/Expected:** 测试命令最多2条，各600秒外层资源上限；包内部295项默认5000ms、5项原15000ms不改，无reporter/retry/worker/heap参数。两次实际必须300/300且无恢复/异常/来源问题才支持“值得提交正式调整方案”；任何一次红立即停止。测试正确性通过与资源证据是否充分分别审阅，显著成本反例须记录，不拿全绿换风险接受。

**采样与收尾口径：** 外部数值采样目标间隔0.2秒、连续有效样本最大间隔1秒；首样本距命令启动和末样本距命令结束均≤1秒。单次命令必须有start/result、退出码与采样器正常退出记录，采样器在命令结束后10秒内停止。只跟随自有命令树，排除采样器本身；PID归属/必需RSS或CPU字段缺失、进程组残留或不可解释的头尾缺口即停。短命进程和绝对峰值仍有采样局限，不能称完整峰值证明。

墙钟取单调时钟；RSS按同一时点命令树求和后取观察最大值，不叠加各PID独立峰。CPU报告命令树采样终值及可确认的命令回收统计，口径/缺口分列，不能当精确独占耗时。原恢复断言按runner实际完成记录，不新增143/300项恢复见证或声称第三方待办清零；两次比较也只属于跨时段观察。

**新增/未测范围说明：** 本片不新增测试案例，以保留原300目录的候选筛选为目的；跨工厂的新回归、正式工程检查和原根全量属于T2，不把现有同文件owner测试当成已验证跨文件隔离。T1结果无论如何都不自动提交产品/测试源。

## P3公开门探针与T2正式调整的后续出口

- [ ] Q0若证明P3公开通道，维护者另行批准原52条矩阵的具体映射、工具/类型预算后执行；不另起一套降低要求的取消矩阵。能力仍缺则只交付需求与成本边界，P3保持blocked。
- [ ] T1若通过，先写正式私有fixture接口、跨工厂新回归、准确新增测试数及目标三轮/整文件/原根默认/工程检查预算，审阅后再改正式测试。默认测试原5秒不变、APP-T单列；不直接复制/tmp或凭两轮绿宣告P2通过。
- [ ] D0若通过，先写显式启用的产品props/events、入口能力差异和legacy兼容回归提案，获审后再落库；不只在Playground留下长期可复用装配（ADR-0010）。
- [ ] P4与E不在这些后续授权中默认启动：P4须适用修复与未测项边界收敛，E须另审K/主题/面板下2/10/20表单、冷启动/往返/容器任务与R要求裁定；无当前预算或最小宽度承诺。

## 自审、提交与本轮结束

本轮只对规格覆盖、接口命名、文件边界、命令总数、停止条件和新旧证据语义做静态自审；链接/Markdown/源SHA允许检查，不运行测试或浏览器。不分派额外独立代理，不把本轮作者自审写成双轴独立复核。

完成后按需提交这两份文档与验收入口指针，不动旧报告/归档。维护者审阅Q0/T0首批范围后决定是否执行；代理等待明确批准，不自动进入D0/T1/P3/P4、E或品牌专项，不推送。

作者文档自审（2026-10-19）：规格§3→Q0/P3后续门，§4→Q0/D0，§5→T0/T1/T2，§6停止与授权边界均有映射；PreviewTicket与既有capture结果不冒充新产品API。新文档链接和历史归档成员引用存在，239源SHA不变，验收入口旧正文逐字保留；未运行测试、浏览器、采样或候选构造。此为作者静态自审，不是独立验收。
