# 阶段零：保留供应商的整体修复设计

日期：2026-10-23。状态：**维护者已认可设计并批准计划Native实施；隔离候选任务1、2已完成，任务3STOP；正式产品未改**。维护者已选择“保留现供应商，先做整体修复设计”。本设计承接[路线提案](2026-10-23-stage-zero-consolidated-route.md)，替代逐文件试补的后续组织方式，不撤销旧失败、预算和STOP。

## 1. 目标与不可变条件

目标是让同一确定来源同时满足原阶段零B01/B03及宿主、资源验证要求，再决定正式交付；不是仅消除几个可见症状。

- 保留八类字段、栅格限制、三模式预览、全部当前开放的属性/样式入口；不接受浅色孤岛或关闭入口缩小验收。
- 拖动取消零提交；默认值的缺省、空串、0、false、中间原文、焦点和同一编辑器/input生命期保留；取消后同实例可再次正常拖动。
- 同formId的不同编辑器实例分属独立owner；旧事件、旧请求、旧释放不能影响新实例或旁实例。
- legacy缺省与显式legacy的公开签名、值转换、正常拖动、提交/关闭语义保留。修正宿主处理器覆盖、清理和实例串扰属于明确缺陷修复，不保留这些错误副作用。
- 不向core加入表单依赖，不改变事实源、session、租约、持久化成功和A/B候选校验合同；不引入第二份业务模型。ADR-0006/0011继续适用，Pro代码不进入仓库。
- OS输入法、活动native中断、自然序列化ERR05仍独立取证；自然渲染异常不补绿ERR05，合成事件和人工throw不冒充原生通过。

本轮只写设计和来源记录，不运行新的修订候选、不安装依赖、不改产品/node_modules/lockfile、不推送或进入阶段一。

## 2. 已证事实、推断与尚未知

| 事实                          | 当前证据                                                        | 设计约束                                           |
| ----------------------------- | --------------------------------------------------------------- | -------------------------------------------------- |
| 活动fallback卸载后B首击无效   | 原版与唯一Sortable候选均失败；候选字节确实被浏览器加载          | 不再把destroy末尾清一个标记作为充分修复            |
| 22个可见颜色入口脱离主题      | 八字段、owner=null、宿主#409eff/白底，开关后原内容不变          | 覆盖整个弹层族，不能仅补ValueInput                 |
| 全卸载后供应商处理器残留      | Manager真实0→1→0、无pageerror，宿主handler未恢复                | 不再给window.onbeforeunload/body.ondrop赋单槽回调  |
| 自然Vue NotFoundError和半卸载 | fresh clean与color-swap链路均复现，一侧仍报告canCapture         | 首先区分载体/供应商/接缝；异常后禁止保留假健康端口 |
| 下游不会自动获得根pnpm补丁    | form-create构建external含@form-create/designer；files只发布dist | 选择可随产物交付的适配方式，不能只验证仓库Vite别名 |

Sortable 1.14.0的destroy无条件调用_onDrop，后者最终_nulling会清模块级rootEl/dragEl/Sortable.active；这是源码事实。某个非活动引擎先销毁、导致目标所有者destroy时active已空，是合理的顺序假设，**尚无插桩时序证明**。新设计不能以这项假设已被证实为前提。

此前七类来源、失败第八类及新主题/卸载原件分别保留在[证据包](system-v1/probes/evidence/stage-zero-validation-2026-10-22/README.md)。设计输入版本和源码哈希见[来源记录](system-v1/probes/vendor-repair-design-inputs-2026-10-23.json)。这些是设计依据，不是本设计的实现验收。

## 3. 模块与责任

采用一个私有的“供应商实例运行时”模块，集中保存组件生命期和资源归属。它只管理编辑器资源和交互状态，不保存业务rules/options，不取代既有输入缓冲、FormManager或session。

| 层                         | Interface及责任                                                                  | 不承担                            |
| -------------------------- | -------------------------------------------------------------------------------- | --------------------------------- |
| FormDesigner / FormPreview | 创建实例key，持有内容/弹层容器，消费公开状态和取消收据；预览只使用渲染派生数据   | 重写模型、绕过原capture/save守卫  |
| 私有实例运行时             | 明确owner、代际、资源注销、弹层归属、错误/释放阶段；为键盘和主题提供同一owns判定 | 最近焦点猜owner、全局主题、持久化 |
| 私有供应商适配             | 把运行时能力送到设计器属性规则、直接SFC控件及拖动适配器；保留所有值转换和事件    | 在宿主全局替换ElSelect等组件      |
| Sortable适配内部           | 活动拖动事务、引擎与资源归属、确定结束/取消及迟到拒绝                            | 更新FormCreate业务数组或采集表单  |
| 宿主                       | 既有保存/加载适配器与文档确认；持久化成功由宿主回执决定                          | 通过取消收据推定保存成功          |

建议Interface如下，仅为合同草案，不是新导出或已实现代码：

```ts
type DragRef = Readonly<{ instance: symbol; engine: symbol; generation: number; sequence: number }>;
type CancelReceipt =
  | { status: "confirmed"; ref: DragRef }
  | { status: "blocked"; ref: DragRef; reason: string }
  | { status: "rejected"; reason: "stale" | "foreign" | "unsupported" };
// createInstanceRuntime只对集成包内部可见。
// read() / owns(target) / requestCancel(ref) / dispose()是调用方所需的最小能力。
```

owner由编辑器实例key产生，不从formId、主题名、数组下标或DOM随机class反推。释放收据须区分“已禁止新调用”和“资源已全部释放”；两者之间不可采集。token不进入序列化内容，也不成为公共业务API。

## 4. 拖动：所有权先于清理

### 4.1 稳定事务记录

在拖动准备阶段建立内部记录，至少含实例key、引擎key、代际、事务序号、源节点/父节点/存续锚点、原生或fallback后端、精确ghost/clone引用、监听/定时器/自动滚动资源。记录独立于Sortable.active；后者仅为上游兼容状态，不能作为销毁资格的唯一依据。

同一Document在同一时刻只允许一个已启动的物理拖动；第二实例试图启动时须有明确拒绝/结束原事务规则，不能静默夺取owner。不同Document互不共享该记录。

### 4.2 非活动引擎销毁

非owner销毁只释放它自身的监听、延迟启动、实例登记和插件资源；不得调用会结束他人事务的全局drop/nulling、删除他人ghost、清理他人的自动滚动或点击屏障。插件的destroy/drop/nulling路径也必须核对，不能只给外层destroy加一条if后就认定满足。

### 4.3 取消与活动所有者卸载

1. 复验ref属于当前owner/引擎/代际和活动fallback事务；native未证明主动取消时仍明确unsupported。
2. 先关闭旧代提交资格，状态进入cancelling；同步及排队的所有FormCreate数组变更/事件转发都要复验资格。
3. 通过**适配后的公开取消Interface**结束底层事务。包装层不得调私有_onDrop/_nulling；模块内部可以重构上游实现，但调用方与测试都经过同一Interface。
4. 仅删除本事务ghost/clone，按捕获的存续锚点恢复原DOM；不setRule、不重挂编辑器、不通过序列化回放重建原文。恢复失效或第三方清理异常进入blocked，不能提前报confirmed。
5. 清理本事务自动滚动、计时与捕获监听。普通drop的防误触点击与取消/卸载后的下一次正常点击分列：只释放已结束事务的屏障，不发合成click消费标记，不跳过用户第一次点击。
6. 经过实际结束条件及已排队回调的资格复验后确认。等待条件是资源/代际/DOM状态，不是任意sleep。只有确认后才重新开放可采集状态；原文不合法仍被原输入守卫阻止。

取消可重建本实例的底层拖动引擎，但不能重建FormDesigner、字段/input实例或其缓冲。底层创建/销毁须配对，旧引擎回调失效。活动卸载不必恢复即将移除的编辑器DOM，但同样必须关闭提交资格并完成资源清理。

正常drop、直接拖出区、先入画布再移出、Escape、API、系统中断逐项记账；现有“先入后出会提交”的附加轨迹不能自动改写成取消成功。

## 5. 全部弹层：同一归属用于主题、焦点和快捷键

### 5.1 容器与归属

每个编辑器由Vue声明一个独立、空的overlay容器，与内容容器分开。Teleport只向该容器写其自己负责的节点；运行时不向Vue管理的内容子树尾部append/remove style或手工锚点。该安排消除一种不必要的所有权混用，但**不宣称它已证明修复NotFoundError**。

实例容器是显式启用的增强配置；未配置的legacy消费保留原body挂载默认，不强制改变布局。运行时仍可签发明确owner token并修正资源清理，但只有显式主题范围才附加主题变量。已有直接控件props优先；若其挂载方式与所要求的隔离合同冲突，应报告配置冲突而不是悄悄覆盖或声称隔离通过。

优先使用当前控件公开的append-to/teleported配置；选择局部挂载时同时验证滚动裁切、遮罩层级和键盘焦点。仅有“颜色变对”不算通过。

不支持指定目标的路径，可以使用明确签发的popper-class及owner样式桥接：样式节点归运行时持有，放在独立管理的head位置，不写html/body主题；只作用于签发的具体owner类，随主题/密度更新并按所有者释放。日期现有桥接可复用这一合同，但需移出内容子树并验证清理。

owns(target)同时识别内容根、独立overlay根及明确登记的body弹层token。弹层token在控件配置时签发，不在打开时按最近焦点或activeElement猜测。旧token在释放后不可路由快捷键。

FormManager的编辑Dialog及放弃确认框也必须带所属会话签发的容器/类标记；优先复用现有会话key和modal/content标记，缺失的确认框customClass属于本设计明确的UI接缝。不能全局代理ElMessageBox猜归属；不改变确认前后key/revision复验、明确放弃或保存的既有逻辑。

### 5.2 三类接入，不做全局组件替换

- **设计器自己的属性表单：** 在FcDesigner生成base/props/form/default/control等UI配置规则之后，统一装饰已知弹层控件。递归处理嵌套control，保留Creator/引用字符串等现有联合类型；不是遍历并污染业务rules。
- **直接SFC控件：** ValueInput、ColorInput、工具提示/下拉及样式组件从同一provide取overlay配置，显式props优先；不改值转换、watch、blur/change/change-type或样式值语义。
- **渲染/预览：** FormPreview及设计器试填使用独立解析所得的渲染派生规则；仅派生规则可带UI挂载参数，原业务字符串和生成组件/HTML的源保持。组件/HTML代码预览不串入owner、teleported或探针配置。

背景图片入口的系统文件选择框属于OS窗口，不能用DOM computed证明主题；需要在清单中单列其固有限制和读文件失败处理。它不是把现有入口静默关闭的理由。

选定文件后的FileReader须处理error/abort及释放后的迟到load：读取期间进入本owner的待处理状态，失败保持已有背景值并明确反馈，终止/完成后释放本次资格；用户取消系统选择不产生修改。不能让已释放实例的读取回调写入后来复用的表单。该责任限定在已有BackgroundInput，不扩成上传字段或外部存储能力。

### 5.3 完整库存

| 入口族    | 当前来源                                                           | 必须验证的细项                                               |
| --------- | ------------------------------------------------------------------ | ------------------------------------------------------------ |
| 默认值    | 八字段配置、DateDefaultEditor、ValueInput                          | 单/多选、嵌套control、日期、类型下拉，原文与值类型保持       |
| 普通属性  | 设计器生成的props规则                                              | 数字控制位置、日期对齐、字段类型转换菜单及各可达下拉         |
| 公共样式  | ColorInput、BackgroundInput、BorderInput、FontInput、PositionInput | 颜色/背景、图片相关下拉、边框类型/颜色、字体/字重/装饰、定位 |
| 嵌套样式  | SizeInput、BoxSizeInput、ShadowInput、ShadowContent                | 单位菜单、提示、阴影预设、偏移单位及嵌套颜色                 |
| 工具/预览 | FcDesigner、Warning、TypeSelect、JsonPreview                       | 菜单/树操作、提示、三模式对话框、预览内选择器/日期           |
| 宿主表单  | FormManager及其确认框                                              | Dialog、遮罩、确认与继续编辑、弹层期间IME/Escape和保存归属   |

每个入口须记录触发路径、可达条件、实际组件/容器、token来源、computed变量、焦点、快捷键、关闭/主题交换/卸载清理。样式展开状态和条件按钮必须覆盖，不能仅检查首屏22个颜色入口。

EventConfig/FetchConfig/FnEditor等在当前收口配置下关闭的路径必须以配置/实际不可达作证；仅源码存在不计当前可达，也不能顺手恢复脚本/远程/Pro能力。

## 6. 全局事件、错误与装配

### 6.1 宿主处理器和注册

不再赋值window.onbeforeunload或body.ondrop，也不做“销毁时恢复旧快照”的竞态补救。beforeunload使用可移除的自身listener，只在本实例dirty且exitConfirm启用时请求确认；清洁实例不能取消宿主或另一脏实例已提出的确认。

只在自有content/overlay范围内处理drop、keydown和paste，严格确认owner与当前生命期。保留IME、第三方弹层和宿主快捷键优先级；关闭persistent弹层后不因DOM仍存在而永久阻止Escape。

装配不在宿主全局注册“替代ElSelect/ElColorPicker”。优先使用供应商内部局部组件绑定；FormCreate必需的命名装配仍按app一次安装。对于宿主已注册的同名组件，不能用重复app.use(ElementPlus)静默覆盖；只补确实缺失的必需注册，并记录冲突为明确不兼容而不是强行替换。此项需要装配回归，不把现有代码注释中的“无副作用”当证据。

### 6.2 生命周期和错误

状态顺序为ready → cancelling/disposing → disposed，异常可进入faulted/blocked；离开ready先撤销采集和提交资格。onUnmounted后才能声称Vue子树已释放；资源未清理完则保留失败记录和可重试释放资格，不假报disposed。释放自身资源须幂等，不能吞掉主异常或把它替换为清理异常。

组件内的errorCaptured只标记自身后代错误、撤销本owner的健康端口并继续向宿主报告；不得覆盖app.config.errorHandler。父载体错误不应被伪装成子组件已经捕获。主题载体增加自己拥有的错误边界与明确卸载阶段，以验证其责任，不更改业务输入。

首个前置门必须在最小载体中分别比较：无overlay适配、独立overlay容器、旧桥接，以及仅设计器/仅预览/往返切换。确认第一失败时点和源归属后，才选择对应修订。若问题需要改Vue、Element Plus或FormCreate渲染器内核，**停止本范围**并更新整体提案；不能临时扩大底座补丁。

## 7. 明确源码范围

以下是后续候选可申请的完整范围；本次文档不修改它们。先在隔离探针副本中实施，不对当前安装目录打补丁。

| 范围                                                                                                                    | 允许的责任                                                                     |
| ----------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------ |
| FormDesigner.vue、FormPreview.vue                                                                                       | 私有适配入口、实例/overlay容器、派生渲染、状态/错误集成                        |
| FormManager.vue的Dialog/确认框UI接缝                                                                                    | 复用会话key签发容器/customClass；不改保存、关闭、确认及版本资格算法            |
| DateDefaultEditor.vue、designer-config.ts                                                                               | 日期owner接入、UI配置装饰；默认值业务转换和原文合同保持                        |
| form-create-setup.ts                                                                                                    | 不覆盖宿主组件的一次性装配；不得引入全局替换控件                               |
| 新私有internal/editor-runtime.ts、internal/overlay-owner.ts、internal/vendor-entry.ts                                   | 集中上述资源/owner合同，不导出公共业务API；路径位于隔离副本的form-create/src下 |
| 供应商FcDesigner.vue、DragBox.vue、types/index.d.ts                                                                     | 设计器UI规则、生命周期、预览/工具弹层和拖动配置接缝                            |
| 供应商ValueInput、ColorInput、Warning、TypeSelect、JsonPreview                                                          | 直接弹层归属；已有值转换和事件保持                                             |
| 供应商style/BackgroundInput、BorderInput、FontInput、PositionInput、ShadowContent、ShadowInput、SizeInput、BoxSizeInput | 所有当前可达样式下拉/提示/嵌套弹层接入同一helper                               |
| vuedraggable 4.1.0源码及声明                                                                                            | 公开取消Interface、代际资格、精确DOM/资源恢复与收据                            |
| Sortable 1.14.0 ESM                                                                                                     | 事务owner、非owner销毁、确定取消、插件/滚动/点击屏障清理                       |
| 临时ThemeIsolation/Manager/宿主探针及必要回归                                                                           | 对应真实组件取证，不再建立监督框架                                             |
| 临时构建/消费者载体、license/来源/补丁清单                                                                              | 验证消费者确实收到适配，重建和回退可复现                                       |

不包含core/designer业务逻辑、FormManager保存/关闭等业务算法、Vue/EP/FormCreate渲染器内核、其他未开放供应商能力。需要扩大其中任一项则一次汇总原因和新设计后再确认，不逐个源文件补卡。正式迁入的package/vite配置变更在门通过后单独交付，不由探针批准自动获得。

## 8. 补丁怎样交给消费者

比较三种办法：

| 方式                                    | 判断                                                                                   |
| --------------------------------------- | -------------------------------------------------------------------------------------- |
| 只保留仓库根pnpm patch或Vite alias      | 不采用为正式交付：当前供应商external，下游不会自动继承                                 |
| 发布独立私有npm fork让消费者替换        | 暂不采用：增加发行/命名/供应链入口，当前没有批准发布                                   |
| 集成包内部构建一个固定MIT供应商适配模块 | **建议**：上游原件+显式补丁生成私有模块，打入form-create产物，Vue/EP及原渲染器继续外置 |

私有适配模块同时承载legacy与retained，以修正两者的资源串扰；legacy的公开数据/交互合同必须另有对照，而不是继续调用一个未经修复、会污染宿主的默认分支。FormDesigner单一入口仍保留editingMode选择，不增加第二套公开表单组件。

来源固定为designer3.5.0、vuedraggable4.1.0、Sortable1.14.0；当前renderer3.3.4、Vue3.5.43、EP2.14.6作实测基线。包元数据均声明MIT；正式纳入前还须复制并核对实际LICENSE/NOTICE、原始发行内容和校验值，不以元数据代替许可材料。ADR-0006的Pro红线仍须逐文件核查。

构建输入在源码中保留上游完整所需MIT文件、版本/来源/哈希、统一补丁和license；不提交整个node_modules，不依赖个人/tmp路径，不在消费者install时联网取源码或静默修改其依赖。构建失败/补丁上下文漂移必须硬失败，不能回落到原版后仍宣称修复生效。

建议目录为form-create下的vendor/upstream（固定原件及许可证）、vendor/patches（按责任组织的统一补丁）、vendor/manifest.json（版本/来源/哈希）及构建生成的私有适配入口；生成文件不作为另一份可手工修改的事实源。探针阶段只在隔离副本验证该结构，正式目录和构建脚本待门通过后再迁入。此供应商适配为兼容与生命周期修复，不用于ADR-0006明令避免的多框架设计器扩展fork。

现peer为Vue^3.5.0、EP^2.11.1。本设计不擅自缩窄它们。首轮候选用锁定基线；正式消费门须补原最低peer及当前基线对照，或另行提出peer范围变更。ColorPicker的append-to官方标注2.10.5并已在本地2.14.6源码核对；不能据此假定DatePicker或所有其他控件具有相同属性。EP不需要因此升级。

在隔离副本中构建并pack，使用无工作区alias/根patch的独立消费者载体安装本地产物，确认原生 import 不再逃逸到未适配designer/Sortable；保留实际模块图和哈希。不能只在Playground别名下通过。比较产物体积、首次挂载和切换/卸载资源，不设无来源的阈值。

回退以最后已验收包/提交为完整单位；未采用的新功能保持不可用，不能静默把取消从confirmed降为普通drop或重建恢复。正式发布、版本调整、推送/PR/合并仍逐项由维护者决定。

## 9. 一次完整验收合同与停止条件

后续不是每补一个文件冻结一次，而是按以下依赖门推进同一候选。失败原件不覆盖，状态表区分未跑/失败/通过；设置错误可纠正驱动，但不得改产品来迁就错误断言。

| 门                | 必要证据                                                                                                                 | 停止条件                                                    |
| ----------------- | ------------------------------------------------------------------------------------------------------------------------ | ----------------------------------------------------------- |
| G0 渲染/卸载归因  | fresh最小载体、首异常时点、错误前后两份内容/原文/端口、明确组件责任；复现后定向RED→GREEN                                 | 无法区分载体与供应商，或需要范围外底座改动                  |
| G1 拖动所有权     | 活动A销毁前/中/后分别销毁非活动B；同实例API/Escape；首击、迟到/重复/旧ref、ghost/滚动/资源配对；原文同节点               | 任一跨owner作用、零提交/原文/确定结束不满足                 |
| G2 全弹层         | 第5.3完整库存、两实例×浅深×两密度、交换/开关/重挂；嵌套面板、遮罩/滚动/焦点、三预览入口及宿主对照                        | 不可达被错误判可达、可达入口无明确owner、裁切/主题/键盘失败 |
| G3 全局/装配/宿主 | 宿主handler身份不变，0→多实例→0全部资源归属；非LIFO释放、宿主中途更新handler、两个app/外部EP组件；实际Ctrl/Cmd+S焦点路由 | 残留、覆盖宿主注册/处理器、串保存owner或假成功              |
| G4 业务与原生     | 原完整B03 N/T/D/H/M适用行，八字段两布局的取消和正常对照、原文/值存在性；真实OS/活动native/ERR05分列                      | 已知失败或原生未知不豁免；不重复R重建路线                   |
| G5 消费与资源     | 独立pack消费者、实际模块来源、最低peer/当前基线、2/10/20原探针规模及相同容器几何                                         | 只有alias生效、许可/哈希/peer缺证、资源回归无法解释         |
| G6 最终出口       | 固定最终源码，默认根测试、build、lint及严格类型四命令一次完整运行；独立Standards/Spec和35项原清单逐项审阅                | 任一所需命令/矩阵失败或用户未接受失败路线，不标完成         |

G0–G3先做能改变下一动作的最小RED→GREEN；只有候选有资格才进入完整G4–G6，不反复跑950或旧96条作为诊断。原来批准的3项15秒例外保留，不扩大时限、不加重试。独立审查对一次完整固定增量进行，发现确定问题后最多一次作者修复并复验，不循环发起同一审查。

G6的四命令为 `pnpm test`、`pnpm build`、`pnpm lint`，以及 `pnpm --filter @flowduet/form-create exec vue-tsc --noEmit -p <候选严格tsconfig绝对路径>`。隔离副本的执行目录、第四条的准确配置/包含文件和受测来源由执行计划固定，不把现有个人tmp配置当成正式工程接口。严格类型覆盖包装层、声明及载体；供应商JS另由构建和真实组件路径验证，不能冒称全部JS已作严格类型检查。正式PR的Node22/24 CI仍属后续合并规则，不伪造本地运行等同于远端CI。

实现预算须由下一份书面执行计划定义为一个整体，不重新开放已耗尽的第八类单次实验。设计不承诺一次实现必然通过；任何STOP说明失败对象、原件、未执行项和下一责任，不制造性能预算、人日或交付日期。

G4的展开以[原B03细化合同](2026-10-16-b03-minimal-production-fixes-proposal.md)为准，G6对照[原35项出口审计](system-v1/probes/completion-audit-2026-10-22.md)逐项给出准确来源。新设计不以四个修复主题取代完整任务清单；旧P2测试/几何/资源证据仍只证明其原受测输入。

## 10. 设计审阅与下一步

2026-10-23：维护者已明确回复“认可设计，继续编写执行计划”。[执行计划](plans/2026-10-23-stage-zero-integrated-vendor-repair.md)已编写，维护者随后批准计划并选择Native，当前执行在任务3前置条件STOP；下面保留设计阶段的授权边界。

本设计建议一次性审阅第3–9节，确认范围、正式交付方向和验收合同；批准设计后再形成可执行计划及明确候选预算，**不是现在开始修改源码**。后续若批准实现，应一次批准完整候选范围，只有真正越出第7节才再次询问，不对列表内每个文件重复请示。

当前阶段零仍未通过，旧P2成果与全部失败保持。维护者现在只需审阅此设计并指出需要调整的合同；本会话根据审阅收敛执行计划，未启动后台修复。OS走查准备见[人工步骤](system-v1/probes/v01-manual-verification-2026-10-23.md)，在候选来源稳定后由维护者操作、本会话读回。

## 来源

本轮自审已核对：默认body与显式容器不冲突；Dialog/确认框与文件读取迟到责任已纳入；对Sortable顺序和Vue异常均只作有标记的推断；下游交付不依赖根patch；24个静态SFC不冒称全部可达；原生未知不豁免；G0–G6最终回到原35项及B03完整合同。未运行产品测试或新候选，本轮检查仅为来源哈希、文档链接和格式。

- 本地权威：锁定依赖的package.json/ESM/SFC、form-create当前构建external和files、既有18项manifest及两组失败原件；详见来源记录。
- [Element Plus ColorPicker公开属性](https://element-plus.org/en-US/component/color-picker)：append-to/teleported是控件显式配置，不代表供应商所有嵌套控件已经使用。
- [Element Plus Dialog](https://element-plus.org/en-US/component/dialog)：嵌套/挂载方式需要单独处理遮罩与容器，不从单个下拉的成功外推。
- [Element Plus DatePicker](https://element-plus.org/en-US/component/date-picker)：按实际公开能力和当前锁定源码设计，未从ColorPicker推导通用append-to。
