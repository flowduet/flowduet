export default { server: { host: "127.0.0.1", port: 5427, strictPort: true } };
