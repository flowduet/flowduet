import { BpmnModel, flowableAdapter } from '@flowduet/core';
import { DingtalkDesigner, BpmnCanvas } from '@flowduet/designer';
import { FormDesigner, FormManager, FormPreview, FlowDesignSession, type FormDesignerCaptureResult, type FormDesignerEditingState } from '@flowduet/form-create';
const designer: InstanceType<typeof FormDesigner> | undefined = undefined;
function inspect(d: InstanceType<typeof FormDesigner>): [FormDesignerCaptureResult,FormDesignerEditingState] { return [d.captureContent(),d.readEditingState()]; }
void [designer, inspect, FormManager, FormPreview, DingtalkDesigner, BpmnCanvas, new FlowDesignSession(BpmnModel.create({processId:'p2',adapter:flowableAdapter}))];
