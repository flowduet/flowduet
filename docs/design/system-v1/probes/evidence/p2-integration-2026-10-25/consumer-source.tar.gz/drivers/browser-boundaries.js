async page => {
 const savedBefore=await page.locator('[data-test="saved"]').textContent();
 await page.getByRole('textbox',{name:'数值默认值原文',exact:true}).fill('-');
 await page.getByRole('button',{name:'保存设计文档',exact:true}).click();
 const busy=JSON.parse(await page.locator('[data-test="capture"]').textContent());
 if(busy.status!=='blocked')throw Error('incomplete number not blocked');
 if(await page.locator('[data-test="saved"]').textContent()!==savedBefore)throw Error('blocked save replaced document');
 if(await page.getByRole('textbox',{name:'数值默认值原文',exact:true}).inputValue()!=='-')throw Error('blocked save lost raw');
 await page.getByRole('textbox',{name:'数值默认值原文',exact:true}).fill('0');
 await page.getByRole('button',{name:'保存设计文档',exact:true}).click();
 await page.waitForFunction(()=>document.querySelector('[data-test="status"]').textContent==='设计文档已保存');
 await page.getByRole('button',{name:'切换编辑模式',exact:true}).click();
 await page.getByRole('textbox',{name:'申请说明',exact:true}).waitFor();
 await page.getByRole('button',{name:'读取当前内容',exact:true}).click();
 if(JSON.parse(await page.locator('[data-test="capture"]').textContent()).status!=='captured')throw Error('legacy export failed');
 const rules=JSON.parse(await page.locator('[data-test="content"]').textContent());
 if(rules.find(r=>r.field==='p2_number').value!==0)throw Error('legacy number changed');
 await page.getByRole('button',{name:'检查宿主处理器',exact:true}).click();
 const mountedHost=JSON.parse(await page.locator('[data-test="host"]').textContent());
 await page.getByRole('button',{name:'卸载编辑器',exact:true}).click();
 await page.waitForFunction(()=>document.querySelector('[data-test="status"]').textContent==='编辑器已卸载');
 const unmountedHost=JSON.parse(await page.locator('[data-test="host"]').textContent());
 const result={incompleteNumberBlocked:true,savedDocumentUnchangedWhileBlocked:true,rawPreserved:true,legacyExport:true,mountedHost,unmountedHost};
 await page.evaluate(result=>{document.body.dataset.p2BoundaryResult=JSON.stringify(result);},result);
 return result;
}
