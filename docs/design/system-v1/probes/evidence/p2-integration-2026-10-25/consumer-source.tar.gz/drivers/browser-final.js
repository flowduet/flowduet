async page => {
 const errors=[];page.on('pageerror',error=>errors.push(String(error)));
 await page.reload();await page.getByRole('textbox',{name:'申请说明',exact:true}).waitFor();await page.locator('._fd-drag-mask').first().click();
 await (async page => {
 const results=[];
 const readRules=async()=>JSON.parse(await page.locator('[data-test="content"]').textContent());
 const save=async()=>{await page.getByRole('button',{name:'保存设计文档',exact:true}).click();await page.waitForFunction(()=>document.querySelector('[data-test="status"]').textContent==='设计文档已保存');if(await page.locator('[data-test="error"]').textContent())throw Error('save error');return readRules();};
 try {
  await page.getByRole('textbox',{name:'文字默认值原文',exact:true}).fill('中文申请说明');
  let rules=await save();if(rules.find(r=>r.field==='p2_text').value!=='中文申请说明')throw Error('Chinese value mismatch');results.push('retained Chinese text captured');
  await page.getByRole('button',{name:'恢复设计文档',exact:true}).click();
  await page.getByRole('textbox',{name:'申请说明',exact:true}).waitFor();
  await page.locator('._fd-drag-mask').first().click();
  if(await page.getByRole('textbox',{name:'文字默认值原文',exact:true}).inputValue()!=='中文申请说明')throw Error('reopen mismatch');results.push('saved document reopened');
  await page.getByRole('textbox',{name:'文字默认值原文',exact:true}).fill('');
  rules=await save();let text=rules.find(r=>r.field==='p2_text');if(!Object.hasOwn(text,'value')||text.value!=='')throw Error('empty string lost');results.push('explicit empty string preserved');
  await page.getByRole('checkbox',{name:'设置文字默认值',exact:true}).uncheck();
  rules=await save();text=rules.find(r=>r.field==='p2_text');if(Object.hasOwn(text,'value'))throw Error('unset still has value');results.push('unset omits value');
  if(rules.find(r=>r.field==='p2_number').value!==0||rules.find(r=>r.field==='p2_switch').value!==false)throw Error('0/false changed');results.push('0 and false preserved');
  if(JSON.stringify(rules).includes('__flowduet'))throw Error('UI marker leaked');results.push('no UI marker in serialized rules');
  await page.getByRole('button',{name:'恢复设计文档',exact:true}).click();
  await page.getByRole('textbox',{name:'申请说明',exact:true}).waitFor();await page.locator('._fd-drag-mask').first().click();
  if(await page.getByRole('checkbox',{name:'设置文字默认值',exact:true}).isChecked())throw Error('unset reopen changed');results.push('unset document reopened');
  await page.getByRole('button',{name:'校验导出 XML',exact:true}).click();await page.waitForFunction(()=>document.querySelector('[data-test="status"]').textContent.startsWith('XML 导出成功'));results.push('deploy XML exported (no engine deployment)');
  console.log(JSON.stringify({passed:results}));
 } catch(error) {console.log(JSON.stringify({passed:results,failed:String(error)}));throw error;}
}
)(page);
 await page.screenshot({path:'/Users/l/.codex/worktrees/stage-zero-p2-integration/flowduet/output/playwright/p2-retained.png',fullPage:true});
 await page.locator('._fd-drag-mask').nth(2).click();
 const boundaries=await (async page => {
 const savedBefore=await page.locator('[data-test="saved"]').textContent();
 await page.getByRole('textbox',{name:'数值默认值原文',exact:true}).fill('-');
 await page.getByRole('button',{name:'保存设计文档',exact:true}).click();
 const busy=JSON.parse(await page.locator('[data-test="capture"]').textContent());
 if(busy.status!=='blocked')throw Error('incomplete number not blocked');
 if(await page.locator('[data-test="saved"]').textContent()!==savedBefore)throw Error('blocked save replaced document');
 if(await page.getByRole('textbox',{name:'数值默认值原文',exact:true}).inputValue()!=='-')throw Error('blocked save lost raw');
 await page.getByRole('textbox',{name:'数值默认值原文',exact:true}).fill('0');
 await page.getByRole('button',{name:'保存设计文档',exact:true}).click();
 await page.waitForFunction(()=>document.querySelector('[data-test="status"]').textContent==='设计文档已保存');
 await page.getByRole('button',{name:'切换编辑模式',exact:true}).click();
 await page.getByRole('textbox',{name:'申请说明',exact:true}).waitFor();
 await page.getByRole('button',{name:'读取当前内容',exact:true}).click();
 if(JSON.parse(await page.locator('[data-test="capture"]').textContent()).status!=='captured')throw Error('legacy export failed');
 const rules=JSON.parse(await page.locator('[data-test="content"]').textContent());
 if(rules.find(r=>r.field==='p2_number').value!==0)throw Error('legacy number changed');
 await page.getByRole('button',{name:'检查宿主处理器',exact:true}).click();
 const mountedHost=JSON.parse(await page.locator('[data-test="host"]').textContent());
 await page.getByRole('button',{name:'卸载编辑器',exact:true}).click();
 await page.waitForFunction(()=>document.querySelector('[data-test="status"]').textContent==='编辑器已卸载');
 const unmountedHost=JSON.parse(await page.locator('[data-test="host"]').textContent());
 const result={incompleteNumberBlocked:true,savedDocumentUnchangedWhileBlocked:true,rawPreserved:true,legacyExport:true,mountedHost,unmountedHost};
 await page.evaluate(result=>{document.body.dataset.p2BoundaryResult=JSON.stringify(result);},result);
 return result;
}
)(page);
 const result={textAssertionsPassed:true,boundaries,pageErrors:errors};
 await page.evaluate(result=>{document.body.dataset.p2FinalResult=JSON.stringify(result);},result);
 return result;
}
