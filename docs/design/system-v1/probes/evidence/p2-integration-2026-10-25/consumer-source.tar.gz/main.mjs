import {createApp,h,ref,markRaw,nextTick} from 'vue';
import ElementPlus from 'element-plus';
import 'element-plus/dist/index.css';
import '@flowduet/designer/style.css';
import '@vue-flow/core/dist/style.css';
import '@flowduet/form-create/style.css';
import {BpmnModel,flowableAdapter} from '@flowduet/core';
import {FlowDesignSession,FormDesigner,FormPreview,exportDeployXml} from '@flowduet/form-create';
const expectedBeforeUnload = () => undefined;
const expectedDrop = () => undefined;
window.onbeforeunload = expectedBeforeUnload;
document.body.ondrop = expectedDrop;
const session=new FlowDesignSession(BpmnModel.create({processId:'p2',adapter:flowableAdapter}));
const opened=await session.open(await(await fetch('/design.flowduet.json')).text());
const targetId=opened.forms[0].id;
const initialRules=JSON.stringify([
 {type:'input',field:'p2_text',title:'申请说明',value:'初始说明'},
 {type:'input',field:'p2_multiline',title:'补充说明',props:{type:'textarea'},value:'初始补充'},
 {type:'inputNumber',field:'p2_number',title:'申请金额',value:0},
 {type:'switch',field:'p2_switch',title:'是否加急',value:false}
]);
session.updateFormContent(targetId,initialRules,opened.forms[0].options);
const app=createApp({setup(){
const editor=ref(null),mode=ref('retained'),visible=ref(true),preview=ref(false),generation=ref(0),status=ref('就绪'),saved=ref(''),content=ref(''),captureStatus=ref(''),hostStatus=ref(''),error=ref('');
const form=ref(markRaw(session.current.forms.find(f=>f.id===targetId)));
function hostCheck(){hostStatus.value=JSON.stringify({beforeUnload:window.onbeforeunload===expectedBeforeUnload,drop:document.body.ondrop===expectedDrop});}
function capture(){const d=editor.value;if(!d)throw Error('编辑器未挂载');const result=mode.value==='retained'?d.captureContent():{status:'captured',content:d.exportContent()};captureStatus.value=JSON.stringify(result.status==='captured'?{status:'captured'}:result);if(result.status!=='captured'||!result.content){status.value='捕获拒绝，保留当前输入';return null;}content.value=result.content.rules;return result.content;}
async function save(){error.value='';try{const c=capture();if(!c)return;session.updateFormContent(targetId,c.rules,c.options);saved.value=(await session.save()).json;status.value='设计文档已保存';}catch(e){error.value=String(e);}}
async function reopen(){error.value='';try{if(!saved.value)throw Error('没有已保存文档');visible.value=false;await nextTick();const restored=await session.open(saved.value);form.value=markRaw(restored.forms.find(f=>f.id===targetId));generation.value++;visible.value=true;status.value='已恢复设计文档';}catch(e){error.value=String(e);}}
async function switchMode(){visible.value=false;await nextTick();mode.value=mode.value==='retained'?'legacy':'retained';generation.value++;visible.value=true;status.value='已切换 '+mode.value;}
async function unmount(){visible.value=false;await nextTick();hostCheck();status.value='编辑器已卸载';}
return()=>h('main',{style:'padding:16px'},[
h('h1','P2 三包独立消费核对'),h('p','当前模式：'+mode.value),
h('button',{onClick:capture},'读取当前内容'),h('button',{onClick:save},'保存设计文档'),h('button',{onClick:reopen},'恢复设计文档'),h('button',{onClick:switchMode},'切换编辑模式'),h('button',{onClick:()=>{preview.value=!preview.value}},'切换试填预览'),h('button',{onClick:unmount},'卸载编辑器'),h('button',{onClick:hostCheck},'检查宿主处理器'),
h('button',{onClick:async()=>{try{const xml=await exportDeployXml(session.current.model,session.current.forms);status.value='XML 导出成功 '+xml.length;}catch(e){error.value=String(e);}}},'校验导出 XML'),
h('p',{'data-test':'status'},status.value),h('p',{'data-test':'error',style:'color:red'},error.value),h('p',{'data-test':'capture'},captureStatus.value),h('p',{'data-test':'host'},hostStatus.value),
visible.value?h(FormDesigner,{ref:editor,key:generation.value,name:form.value.name,editingMode:mode.value,rules:form.value.rules,options:form.value.options,onSave:save}):null,
preview.value?h(FormPreview,{form:form.value}):null,
h('details',[h('summary','捕获内容与已保存文档'),h('pre',{'data-test':'content'},content.value),h('pre',{'data-test':'saved'},saved.value)])]);
}});
app.use(ElementPlus).mount('#app');
